﻿using FringesDataLayer;
using FringesRepositories;
using System.Collections.ObjectModel;

namespace FringesWPF
{
    public class MainWindowViewModel
    {
        UnitOfWork unitOfWork = new UnitOfWork(new FringesDbContext());
        public ObservableCollection<Customer> Customers { get; set; }

        public MainWindowViewModel()
        {
            var context = new FringesDbContext();
            Customers = new ObservableCollection<Customer>(context.Customers);
        }
    }
}
