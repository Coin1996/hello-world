﻿using System;

namespace FringesRepositories
{
    public interface IUnitOfWork : IDisposable
    {
        int CompleteWork();
    }
}
