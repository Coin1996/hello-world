﻿using FringesDataLayer;

namespace FringesRepositories
{
    public class CustomerRepository : Repository<Customer>
    {
        public CustomerRepository(FringesDbContext context)
            : base(context)
        {
        }
    }
}
