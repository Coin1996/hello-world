﻿using FringesDataLayer;

namespace FringesRepositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly FringesDbContext context;
        public UnitOfWork(FringesDbContext context)
        {
            this.context = context;
        }

        public Repository<Customer> Customers { get; private set; }
        public int CompleteWork()
        {
            return context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }
    }
}
