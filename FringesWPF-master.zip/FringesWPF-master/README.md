# FringesWPF
A simple Customer Management project using WPF / MVVM with Entity Framework.

I'd appreciate any comments or advice on improving my code or ways to make my projects better. Thanks.
