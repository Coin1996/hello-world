namespace FringesDataLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UserEntities : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        CustomerID = c.Int(nullable: false, identity: true),
                        DateOfBirth = c.DateTime(nullable: false),
                        Street = c.String(),
                        Town = c.String(),
                        PostCode = c.String(),
                        HomeNo = c.Int(nullable: false),
                        Forename = c.String(),
                        Lastname = c.String(),
                    })
                .PrimaryKey(t => t.CustomerID);
            
            CreateTable(
                "dbo.Staffs",
                c => new
                    {
                        StaffID = c.Int(nullable: false, identity: true),
                        PassHash = c.String(),
                        Salt = c.String(),
                        Forename = c.String(),
                        Lastname = c.String(),
                    })
                .PrimaryKey(t => t.StaffID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Staffs");
            DropTable("dbo.Customers");
        }
    }
}
