namespace FringesDataLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<FringesDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(FringesDbContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            context.Customers.AddOrUpdate(
                new Customer { Forename = "Samantha", Lastname = "Logue", DateOfBirth = DateTime.Parse("30/10/1991"), Street = "15 Tiree Street", Town = "Glasgow", PostCode = "G21 2AJ", HomeNo = 07478679135 },
                new Customer { Forename = "Sian", Lastname = "Logue", DateOfBirth = DateTime.Parse("30/10/1994"), Street = "99 Acredyke road", Town = "Glasgow", PostCode = "G41 2AJ", HomeNo = 07478679135 },
                new Customer { Forename = "Sharon", Lastname = "Logue", DateOfBirth = DateTime.Parse("08/01/1969"), Street = "99 Acredyke road", Town = "Glasgow", PostCode = "G55 9LI", HomeNo = 07478679135 }
                );

            context.SaveChanges();
        }
    }
}
