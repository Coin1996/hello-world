﻿namespace FringesDataLayer
{
    public class Staff : User
    {
        public int StaffID { get; set; }
        public string PassHash { get; set; }
        public string Salt { get; set; }

    }
}
