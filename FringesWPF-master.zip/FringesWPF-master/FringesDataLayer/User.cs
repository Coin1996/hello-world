﻿namespace FringesDataLayer
{
    public class User
    {
        public string Forename { get; set; }
        public string Lastname { get; set; }
    }
}
