﻿using System;

namespace FringesDataLayer
{
    public class Customer : User
    {
        public int CustomerID { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Street { get; set; }
        public string Town { get; set; }
        public string PostCode { get; set; }
        public long HomeNo { get; set; }
    }
}