﻿using System.Data.Entity;

namespace FringesDataLayer
{
    public class FringesDbContext : DbContext
    {
        public FringesDbContext()
            : base("FringesDb")
        {
        }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Staff> StaffMembers { get; set; }




    }
}
